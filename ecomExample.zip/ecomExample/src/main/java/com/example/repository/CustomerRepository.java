package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.beans.Customer;

public interface CustomerRepository extends CrudRepository<Customer, String> {
	Customer findBycustomerId(String customerId);
}