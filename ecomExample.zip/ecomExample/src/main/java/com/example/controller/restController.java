package com.example.controller;


import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.beans.Customer;
import com.example.beans.Item;
import com.example.repository.CustomerRepository;
import com.example.repository.UserRepository;
import com.example.service.CartService;
import com.example.service.CustomerService;
import com.fasterxml.jackson.core.JsonProcessingException;


@RestController
public class restController {
	
	Item item;
	
	 @Autowired
     private UserRepository userRepository;
	 @Autowired
	 private CartService cartService;
	 @Autowired
	 private CustomerRepository customerRepository;
	 @Autowired
	 private CustomerService customerService;
	 
	 
	@RequestMapping(value="/")
	public String showHi() {
		return "Hellow from the HI method";
	}
	@RequestMapping(value="/getval",method=RequestMethod.GET)
	public Iterable<Item> getItemdetails(){
		return userRepository.findAll();
	}
	
	@RequestMapping(value="/getfromform/{id}",method=RequestMethod.GET)
	public Optional<Item> showRecieved(@PathVariable int id) {
		return userRepository.findById(id);
	}
	@RequestMapping(value="/getpostvalue", method=RequestMethod.POST)
	public String getPostValue(@RequestBody Item item) {
		System.out.println(item.getItem());
		userRepository.save(item);
	    return "Saved";
	}
	@RequestMapping(value="/getByNumber/{itemNumber}",method=RequestMethod.GET)
	public Item showItemRecieved(@PathVariable int itemNumber) {
		return userRepository.findByitemNumber(itemNumber);
	}
	@RequestMapping(value="/getCartValue",method=RequestMethod.POST)
	public String getCartValue(@RequestBody String jsonAsString) throws JsonProcessingException, IOException {
		String returnValue = cartService.getCartItemSummary(jsonAsString);
		System.out.println(returnValue);
		return returnValue;
	}
	@RequestMapping(value="/getCustomerValue", method=RequestMethod.POST)
	public String getCustomerValue(@RequestBody Customer customer) {
		Customer customerRecieved = customerRepository.findBycustomerId(customer.getCustomerId());
		return customerService.getCustomerSummary(customerRecieved);
	}
	
}
