package com.example.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cart {

	@Id
	@Column(name="cart_id")
	int cartId;
	
	@Column(name="item_no")
	int itemNumber;
	
	@Column(name="item_qty")
	int itemQuantity;

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Integer getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	
	public Cart() {
		
	}
	
	public Cart(int cartId, int itemNumber, int itemQuantity) {
		this.cartId = cartId;
		this.itemNumber = itemNumber;
		this.itemQuantity = itemQuantity;
	}
	
	public String getCart() {
		return this.cartId + "," + this.itemNumber + "," + this.itemQuantity;
	}
}
