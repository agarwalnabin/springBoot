package com.example.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cust_tbl")
public class Customer {
	
	@Id
	@Column(name="email")
	String customerId="";
	
	@Column(name="name")
	String name="";
	
	@Column(name="address")
	String address="";

	@Column(name="contact_no")
	String contactNumber="";
	
	@Column(name="cart_id")
	int cartId;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	public Customer() {
		//Default Constructor
	}
	public Customer(String name, String customerId, String address, String contactNumber, int cartId) {
		this.name = name;
		this.address = address;
		this.customerId = customerId; // customerId holds email
		this.contactNumber = contactNumber;
		this.cartId = cartId;
	}
	public String getCustomerDetails() {
		return this.name + "," + this.customerId + "," + this.address + "," + this.contactNumber + "," + this.cartId + "\n"; 
	}
}
