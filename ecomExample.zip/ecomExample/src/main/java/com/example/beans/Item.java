package com.example.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
	@Id
	@Column(name="item_no")
	int itemNumber;
	
	@Column(name="item_name")
	String itemName="";
	
	@Column(name="item_price")
	double itemPrice;
	
	@Column(name="item_description")
	String itemDes="";
	
	@Column(name="item_quantity")
	int itemQuantity;
	
	public int getItemNumber() {
		return itemNumber;
	}
	public double getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemDes() {
		return itemDes;
	}
	public void setItemDes(String itemDes) {
		this.itemDes = itemDes;
	}
	public int getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Item() {
		//default Constructor Created
	}
	public Item(int itemNumber,String itemDes ,String itemName, int itemQuantity, double itemPrice){
		this.itemNumber = itemNumber;
		this.itemName = itemName;
		this.itemDes = itemDes;
		this.itemQuantity = itemQuantity;
		this.itemPrice = itemPrice;
	}
	public String getItem() {
		return this.itemNumber + "," + this.itemName + "," + this.itemDes + "," + this.itemQuantity + "," + this.itemPrice;
				
	}
}
