package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.beans.Customer;


@Service
public class CustomerService {
	@Autowired
	private CartService cartService;

	public String getCustomerSummary(Customer customerRecieved) {
		double cartValue = cartService.getCartTotalValue(customerRecieved.getCartId());
		String customerDetails = customerRecieved.getName() + "," + customerRecieved.getCartId() + "," + customerRecieved.getCustomerId() + "," + cartValue + "\n";		
		return customerDetails;
	}
}
