package com.example.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.beans.Cart;
import com.example.beans.Item;
import com.example.repository.CartRepository;
import com.example.repository.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CartService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private CartRepository cartRepository;
	
	private Item item;
	
	public String getCartItemSummary(String jsonAsString) throws JsonMappingException, JsonProcessingException {
		String returnValue = "";
		ObjectMapper objMap = new ObjectMapper();
		List<Cart> cartRecieved = objMap.readValue(jsonAsString, new TypeReference<List<Cart>>() {});
		Iterator<Cart> itr = cartRecieved.iterator();
		while(itr.hasNext()) {
			Cart c = (Cart) itr.next();
			Item item;
			try {
				item = userRepository.findByitemNumber(c.getItemNumber());
				if(item != null) {
					if(item.getItemQuantity() < c.getItemQuantity()) {
						returnValue = returnValue + "Out Of Stock Item" + item.getItemNumber() + "\n";
					}
					else {
						returnValue = returnValue + "Amount for - " + item.getItemQuantity() + " of " + item.getItemNumber() + " is " + item.getItemPrice() * c.getItemQuantity() + "\n";
					}
				}
				else {
					returnValue = returnValue + "The item - " + c.getItemNumber() + " is not valid \n";
				}
			}catch(NullPointerException e) {
				System.out.println(e.getMessage());
			}
		}
		return returnValue;
	}
	
	public double getCartTotalValue(int cartId) {
		List<Cart> cartItem = cartRepository.findBycartId(cartId);
		Iterator<Cart> iterator = cartItem.iterator();
		double cartValue = 0.0;
		int itemNumber, itemQuantity;
		while(iterator.hasNext()) {
			itemNumber = ((Cart)iterator.next()).getItemNumber();
			itemQuantity = ((Cart)iterator.next()).getItemQuantity();
			item = userRepository.findByitemNumber(itemNumber);
			cartValue = cartValue + item.getItemPrice() * itemQuantity;
		}
		return cartValue;
	}
}